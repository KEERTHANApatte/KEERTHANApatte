```python
import cv2
```


```python
im=cv2.imread('cat.jpg',0)
```


```python
cv2.imshow('image',im)
cv2.waitKey()
cv2.DistroyAllWindows()
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    <ipython-input-54-15a2a75a57dd> in <module>
          1 cv2.imshow('image',im)
          2 cv2.waitKey()
    ----> 3 cv2.DistroyAllWindows()
    

    AttributeError: module 'cv2.cv2' has no attribute 'DistroyAllWindows'



```python
window_name="image"
```


```python
im=cv2.cvtColor(im.cv2.COLOR_BGR2HSV)
cv2.imshow(window_name,im)
```


```python
cv2.waitKey()
```


```python
cv2.destroyAllWindows()
```


```python
import cv2
from matplotlib import pyplot as plt
  
# create figure
fig = plt.figure(figsize=(10, 7))
  
# setting values to rows and column variables
rows = 2
columns = 2
  
# reading images
Image1 = cv2.imread('cat.jpg')
Image2 = cv2.imread('cat.jpg')
Image3 = cv2.imread('cat.jpg')
Image4 = cv2.imread('cat.jpg')
  
# Adds a subplot at the 1st position
fig.add_subplot(rows, columns, 1)
  
# showing image
plt.imshow(Image1)
plt.axis('off')
plt.title("First")
  
# Adds a subplot at the 2nd position
fig.add_subplot(rows, columns, 2)
  
# showing image
plt.imshow(Image2)
plt.axis('off')
plt.title("Second")
  
# Adds a subplot at the 3rd position
fig.add_subplot(rows, columns, 3)
  
# showing image
plt.imshow(Image3)
plt.axis('off')
plt.title("Third")
  
# Adds a subplot at the 4th position
fig.add_subplot(rows, columns, 4)
  
# showing image
plt.imshow(Image4)
plt.axis('off')
plt.title("Fourth")
```


```python
import numpy as np
import cv2
im = cv2.imread('cat.jpg',cv2.IMREAD_COLOR)
res = cv2.resize(im,None,fx=10, fy=20, interpolation = cv2.INTER_CUBIC)
cv2.imshow('image window',im)
cv2.imshow("resized pic",resized)
cv2.waitKey()
cv2.destroyAllWindows()
```


```python
import numpy as np
import cv2
height, width = im.shape[:2]
res = cv2.resize(im,(2*width, 2*height), interpolation = cv2.INTER_CUBIC)
```


```python
#transition
import numpy as np
import cv2 as cv
im = cv.imread('cat.jpg',0)
rows,cols = im.shape
M = np.float32([[1,0,100],[0,1,50]])
dst = cv.warpAffine(im,M,(cols,rows))
cv.imshow('im',dst)
cv.waitKey(0)
cv.destroyAllWindows()
```


```python
#scalling
import cv2
from matplotlib import pyplot as plt

im=cv2.imread('cat.jpg',cv2.IMREAD_COLOR)

resized=cv2.resize(im,None,fx=1,fy=2,interpolation=cv2.INTER_CUBIC)

cv2.imshow("original pic",im)
cv2.imshow("resized pic",resized)
cv2.waitKey()
cv2.destroyAllWindows()
```


```python
#rotation
im = cv2.imread('cat.jpg',0)
rows,cols = im.shape
# cols-1 and rows-1 are the coordinate limits.
M = cv2.getRotationMatrix2D(((cols-1)/2.0,(rows-1)/2.0),90,1)
dst = cv2.warpAffine(im,M,(cols,rows))
cv.imshow('im',dst)
cv.waitKey(0)
cv.destroyAllWindows()
```


```python
#affine transformation
im = cv2.imread('cat.jpg')
rows,cols,ch = im.shape
pts1 = np.float32([[50,50],[200,50],[50,200]])
pts2 = np.float32([[10,100],[200,50],[100,250]])
M = cv.getAffineTransform(pts1,pts2)
dst = cv.warpAffine(im,M,(cols,rows))
plt.subplot(121),plt.imshow(im),plt.title('Input')
plt.subplot(122),plt.imshow(dst),plt.title('Output')
plt.show()
```


![png](output_13_0.png)



```python
#perspective trasformation
im = cv2.imread('cat.jpg')
rows,cols,ch = im.shape
pts1 = np.float32([[56,65],[368,52],[28,387],[389,390]])
pts2 = np.float32([[0,0],[300,0],[0,300],[300,300]])
M = cv.getPerspectiveTransform(pts1,pts2)

dst = cv2.warpPerspective(im,M,(100,100))
plt.subplot(121),plt.imshow(im),plt.title('Input')
plt.subplot(122),plt.imshow(dst),plt.title('Output')
plt.show()
```


![png](output_14_0.png)



```python
#scalling
import cv2
from matplotlib import pyplot as plt

im=cv2.imread('cat.jpg',cv2.IMREAD_COLOR)

resized=cv2.resize(im,None,fx=1,fy=2,interpolation=cv2.INTER_CUBIC)


plt.subplot(121),plt.imshow(im),plt.title('Input')
plt.subplot(122),plt.imshow(resized),plt.title('Output')
plt.show()
```


![png](output_15_0.png)



```python

```
